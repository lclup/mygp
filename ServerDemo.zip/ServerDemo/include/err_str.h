#ifndef _ERR_STR_H
#define _ERR_STR_H
#include <packdef.h>



void err_str(const char*,int);


#endif
