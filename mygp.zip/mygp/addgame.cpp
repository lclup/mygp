#include "addgame.h"
#include "ui_addgame.h"
#include "mygp.h"
#include "qDebug"

extern QMap<QString,QString> m_mNameToPostion;
addgame::  addgame(CSqlite*m_sqll,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::addgame)
{
    ui->setupUi(this);
    m_sql=m_sqll;
}

addgame::~addgame()
{
    delete ui;
}


//添加按钮
void addgame::on_pushButton_2_clicked()
{
    QString gname = ui->lineEdit->text();
    QString path = ui->lineEdit_2->text();
    QString sqlStr =QString("insert into t_game (gameName,gamePath) values('%1','%2')").arg(gname,path) ;
    if(m_sql->UpdateSql( sqlStr ))
        qDebug()<<"更新目录成功了";

    auto ite = /*mygp::*/m_mNameToPostion.begin();
    while(ite  != /*mygp::*/m_mNameToPostion.end())
    {
        qDebug()<<ite.key()<<ite.value();
        ++ite;
    }

    emit SIG_updatalist( );
    QMessageBox::about(this,"提示","添加成功");

}

void addgame::on_pushButton_3_clicked()
{

    QString path = QFileDialog::getOpenFileName( this, "选择游戏", "./","(*.exe)");
        if( path.isEmpty() ) return ;
        QFileInfo fi(path);
        ui->lineEdit->setText(fi.baseName());
        ui->lineEdit_2->setText(path);
}

void addgame::on_pushButton_clicked()
{
    this->hide();
}
