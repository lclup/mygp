#include "mygp.h"
#include "ui_mygp.h"
#include<QMessageBox>
#include "ui_useritem.h"
#include <QCryptographicHash>
#include"gamesup.h"
#define MD5_KEY  (1234)
static QByteArray GetMD5(QString str)
{
    QString val = QString("%1_%2").arg(str).arg(MD5_KEY);
    QByteArray buf = val.toLocal8Bit(); //  toLatin1() ASCII 编码  toLocal8Bit Unicode编码
    QByteArray res =  QCryptographicHash::hash(buf ,  QCryptographicHash::Md5 );
    return res.toHex();  // ABF132...  32个长
}

QMap<QString,QString> m_mNameToPostion;

mygp::mygp(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::mygp)
{
    ui->setupUi(this);
    ui->tabWidget->setCurrentIndex(1);
    m_login = new LoginDialog();
    //    m_login = new LoginDialog();

    // m_anager=new managerDlg();
    connect( m_login ,SIGNAL(SIG_loginCommit(QString,QString)) ,
             this , SLOT(slot_loginCommit(QString,QString)) );
    connect( m_login ,SIGNAL(SIG_registerCommit(QString,QString)) ,
             this , SLOT(slot_registerCommit(QString,QString)) );
    Process1 = NULL;
    myProcess = NULL;
    m_login->show();
    //数据库
    m_sql=new CSqlite;

    //加载数据库
    loadSqlAndSetMusicList();
    m_addgame = new addgame(m_sql,nullptr);

    slot_updatalist();

    m_client = new QMyTcpClient;
    m_client ->InitNetWork( "192.168.11.139" , _DEF_PORT);

    m_anager=new managerDlg(m_client,nullptr);

    m_gamesup = new gamesup();
    connect(m_gamesup,SIGNAL(SIG_killProcess()),
            this,SLOT( slot_killProcess() ) );

    connect( m_client , SIGNAL(SIG_ReadyData(char*,int)) ,
             this , SLOT(slot_clientDealData(char*,int))  );
    connect( this , SIGNAL(SIG_ReadyData(char*,int)) ,
             this , SLOT(slot_clientDealData(char*,int))  );
    connect( this , SIGNAL(SIG_ReadyData(char*,int)) ,
             m_anager, SLOT(slot_clientDealData(char*,int))  );


    connect(  m_addgame,SIGNAL(SIG_updatalist()) ,
              this , SLOT( slot_updatalist() ) ) ,


    connect( m_gamesup , SIGNAL(on_pushButton_clicked()),
                     this ,  SLOT(slot_openAudio() ) );

    m_gameCount = 1;
    m_mNameToPostion["炸弹人"] = "D:/IT/GroupProject/1128/mygp/炸弹人.exe";
    m_mNameToPostion["泡泡堂"] = "D:/IT/GroupProject/1128/mygp/BnB.exe";
    connect(m_gamesup->m_pAudioRead, SIGNAL(sig_net_tx_frame(QByteArray)) ,
            this , SLOT(slot_openAudio(QByteArray)) );
    //好友列表
    m_widgetList = new IMToolList("我的好友" , this);

    ui->widget_4->addItem(m_widgetList);
    //动态
    m_widgetList2 = new IMToolList("朋友圈" , this);

    ui->widget_5->addItem(m_widgetList2);
    m_mainMenu = new QMenu(this); // this 传参 指定父控件 , 父控件回收的时候可以回收子控件
    m_mainMenu->addAction("添加好友");
    m_mainMenu->addSeparator();
    m_mainMenu->addAction("创建房间");
    m_mainMenu->addAction("加入房间");

    connect( m_mainMenu , SIGNAL(triggered(QAction*)) , this , SLOT(slot_dealMenu(QAction* )) );

    connect( this , SIGNAL(SIG_addFriend(QString)) ,
             this , SLOT(slot_addFriendRq(QString)) );
    connect(  m_gamesup , SIGNAL(SIG_quitRoom(int)), this , SLOT(slot_quitRoom(int)) );


}

mygp::~mygp()
{
    delete ui;

    if( m_login )
    {
        delete m_login;
    }
    if( m_client )
    {
        delete m_client;
    }
    for( auto ite = m_mapIDToUserItem.begin(); ite!=m_mapIDToUserItem.end(); ++ite)
    {
        delete *ite;
    }
    m_mapIDToUserItem.clear();
    for( auto ite = m_mapIDToUserItem2.begin(); ite!=m_mapIDToUserItem2.end(); ++ite)
    {
        delete *ite;
    }
    m_mapIDToUserItem2.clear();

    if(m_gamesup)
    {
        delete m_gamesup;
    }
    for( auto ite = m_mapfileTOFileInfo.begin(); ite!=m_mapfileTOFileInfo.end(); ++ite)
    {
        delete *ite;
    }
    m_mapfileTOFileInfo.clear();

    if(m_anager)
    {
        delete m_anager;
    }

    if(m_addgame)
    {
        delete m_addgame;
    }

}
//发送音频帧
void mygp::slot_openAudio(QByteArray ba)
{
    ///音频数据帧
    /// 成员描述
    /// int type;
    /// int userId;
    /// int roomId;
    /// QByteArray audioFrame;
    int nlen = ba.size() + 12 ;
    char *buf = new char[nlen];
    char * tmp = buf;

    *(int*)tmp = DEF_PACK_AUDIO_FRAME;
    tmp += sizeof(int);

    *(int*)tmp = m_userID;
    tmp += sizeof(int);

    *(int*)tmp =  m_RoomID;
    tmp += sizeof(int);

    memcpy( tmp , ba.data() , ba.size());
    qDebug()<<"audio frame"<<buf;
    m_client->SendData( buf , nlen);
    delete[] buf;
}

void  mygp:: slot_updatalist()
{
    ui->gamelist->clear();
    sqlStr =QString("select * from t_game")  ;

    resList2.clear();
    resList.clear();
    res = m_sql->SelectSql( sqlStr ,2 , resList);

    //QLlist<QString> ::iterator ite=resList.begin();
    while(!resList.empty())
    {
        ui->gamelist->addItem(resList.front());
        resList.pop_front() ;
        resList2.push_back(resList.front());
        resList.pop_front() ;

    }

}

void mygp::slot_dealMenu(QAction *action)
{

    if( action->text() == "添加好友")
    {
        qDebug()<< "添加好友";
        QString strName = QInputDialog::getText( this , "添加好友" , "输入好友名字");
        QRegExp reg("[a-zA-Z0-9]{1,10}");
        bool res = reg.exactMatch( strName );
        if( res )
        {
            //发送添加好友信号
            Q_EMIT SIG_addFriend(strName);
        }else
        {
            QMessageBox::about(this, "提示" , "用户名非法\n输入10位以内的数字或字母");
        }
    }else if( action->text() == "创建房间" )
    {
        qDebug()<< "创建房间";
    }else if( action->text() == "加入房间" )
    {
        qDebug()<< "加入房间";
    }
}

void mygp::slot_addFriendRq(QString name)
{


    qDebug()<<name<<"----------------------";
    STRU_ADD_FRIEND_RQ rq;
    std::string  strAddName = name.toStdString();
    strcpy_s( rq.m_szAddFriendName , MAX_SIZE , strAddName.c_str() );

    rq.m_userID = m_userID;
    std::string  strUserName =  m_UserName.toStdString();
    strcpy_s( rq.m_szUserName , MAX_SIZE, strUserName.c_str() );

    m_client->SendData( (char*)&rq , sizeof(rq));
}


//获取好友列表
void mygp::slot_FriendInfo(char *buf, int nlen)
{
    STRU_FRIEND_INFO * friendrq = (STRU_FRIEND_INFO *)buf;

    if( m_mapIDToUserItem .find(friendrq->m_userID) == m_mapIDToUserItem.end() )
    {//没找到
        UserItem * item = new UserItem;
        item->setInfo( friendrq->m_userID , friendrq->m_state ,friendrq->m_szName ,
                       QString(":/tx/%1.png").arg(friendrq->m_iconID) );

        m_widgetList->addItem(item);
        connect( item , SIGNAL(SIG_ItemClicked()) ,
                 this, SLOT( slot_UserItemClicked()) );

        m_mapIDToUserItem[ friendrq->m_userID ] = item;

        //        //创建聊天的窗口
        //        ChatDialog * chat = new ChatDialog;
        //        chat->setInfo( friendrq->m_userID  ,friendrq->m_szName);
        //        connect( chat , SIGNAL(SIG_SendChatMsg(int,QString)) ,
        //                 this , SLOT( slot_SendChatRq(int,QString) ) );

        //        m_mapIDToChatdlg[ friendrq->m_userID ] = chat;

    }else
    {//找到
        UserItem * item = m_mapIDToUserItem[ friendrq->m_userID ];

        if( item->m_state == 0 )
        {
            Notify *nf = new Notify;
            nf->setMsg( item->m_name , item->m_id , QString("[ %1 ]上线了").arg(item->m_name));
            nf->showAsQQ();
        }
        item->setInfo( friendrq->m_userID , friendrq->m_state ,friendrq->m_szName ,
                       QString(":/tx/%1.png").arg(friendrq->m_iconID) );
    }

}
//处理好友添加请求
void mygp::slot_dealAddFriendRq(char *buf, int nlen)
{
    STRU_ADD_FRIEND_RQ * rq = (STRU_ADD_FRIEND_RQ *)buf;
    STRU_ADD_FRIEND_RS rs;
    strcpy_s( rs.szAddFriendName , MAX_SIZE , rq->m_szAddFriendName );
    rs.m_friendID = m_userID;
    rs.m_userID = rq->m_userID ;

    if( QMessageBox::question( this , "好友请求" , QString( "用户[%1] 请求添加你为好友").arg(rq->m_szUserName) )
            == QMessageBox::Yes )
    {
        rs.m_result = add_success;
    }else
    {
        rs.m_result = user_refused;
    }
    m_client -> SendData( (char*)&rs , sizeof(rs));
}

void mygp::slot_dealAddFriendRs(char *buf, int nlen)
{
    STRU_ADD_FRIEND_RS* rs = (STRU_ADD_FRIEND_RS *)buf;
    switch( rs->m_result )
    {
    case no_this_user:
        QMessageBox::about(this , "提示","没有此用户");
        break;
    case user_refused:
        QMessageBox::about(this , "提示","用户拒绝添加");
        break;
    case user_is_offline:
        QMessageBox::about(this , "提示","用户离线");
        break;
    case add_success:
        QMessageBox::about(this , "提示", QString("成功添加[%1]为好友").arg(rs->szAddFriendName));
        break;
    }
}
//创建房间请求
void mygp::on_pushButton_14_clicked()
{
    STRU_CREATEROOM_RQ rq;
    rq.m_UserID = m_userID;
    m_client->SendData((char*)&rq , sizeof(rq));
}

//创建房间回复
void mygp::CreateRoomRS(char* buf,int len)
{
    STRU_CREATEROOM_RS * rs = (STRU_CREATEROOM_RS *)buf;

    if(rs->m_lResult == 0)
    {
        QMessageBox::about(this, "提示","已存在，请重新输入");
    }
    else
    {
        QMessageBox::about(this, "提示","创建成功");
        m_nRoomID= rs->m_RoomId;


        m_gamesup->settext(m_nRoomID );

        m_gamesup->show();

    }

}
//加入房间处理
void mygp::dealJoinRoomRs(char *buf, int nlen)
{
    //解析
    STRU_JOINROOM_RS * rs = (STRU_JOINROOM_RS *)buf;
    if( rs->m_lResult )//结果成功
    {//设置房间标志 房间显示以及设置

        //创建音频采集
        char str[4];
        itoa(m_nRoomID,str,4);
        m_gamesup->settext(m_nRoomID);
        m_gamesup->show();
        m_pAudioRead = new Audio_Read;
        connect(m_pAudioRead, SIGNAL(sig_net_tx_frame(QByteArray)) ,
                this , SLOT(slot_sendAudioFrame(QByteArray)) );
    }
}
//处理成员回复
void mygp::dealMemberRq(char *buf, int nlen)
{
    //解析包
    STRU_ROOM_MEMBER_RQ * rq = (STRU_ROOM_MEMBER_RQ *)buf;

    //创建对应的声音模块
    if( m_mapIDToAudioWrite.find(rq->m_UserID ) == m_mapIDToAudioWrite.end() )
    {
        Audio_Write * audioWrite = new Audio_Write;
        m_mapIDToAudioWrite[ rq->m_UserID ] = audioWrite;
    }

}
//退出房间
void mygp::dealLeaveRs(char *buf, int nlen)
{
    //解析包
    STRU_LEAVEROOM_RS* rs = (STRU_LEAVEROOM_RS* )buf;

    //清除音频模块
    auto iteAudio = m_mapIDToAudioWrite.find(rs->m_UserID);
    if( iteAudio != m_mapIDToAudioWrite.end() )
    {
        Audio_Write *item = m_mapIDToAudioWrite[rs->m_UserID];
        delete item;
        m_mapIDToAudioWrite.erase(iteAudio);
    }
}
// 音频处理
void mygp::dealAudioFrame(char *buf, int nlen)
{
    char* tmp = buf;
    tmp += sizeof(int);

    int userId =  *(int*) tmp; //按照四个字节取数据
    tmp += sizeof(int);

    int roomId = *(int*) tmp;
    tmp += sizeof(int);

    if( m_mapIDToAudioWrite.find( userId) != m_mapIDToAudioWrite.end() )
    {
        QByteArray bt(tmp , nlen -12);
        Audio_Write * pAudioWrite = m_mapIDToAudioWrite[userId];
        pAudioWrite->slot_net_rx( bt );
    }
}

void mygp::on_pushButton_clicked()
{
    QStringList resList;
    QString gname = ui->lineEdit->text();
    if(gname == NULL)
    {
        QMessageBox::about(this,"提示","请输入游戏名");
        return;
    }
    sqlStr =QString("select gamePath from t_game where gameName='%1'").arg(gname)  ;


    res = m_sql->SelectSql( sqlStr ,1 , resList);



    if( resList.size())
    {
        myProcess = new QProcess();
        myProcess->start(resList[0]);

        m_gamesup->move(1450,400);
        m_gamesup->show();

    }
    else
        QMessageBox::about(this,"提示","没找到");

}

//离开房间请求
void mygp::slot_quitRoom(int id)
{
    //写离开房间包
    STRU_LEAVEROOM_RQ rq;
    rq.m_nUserId = m_userID;
    rq.m_RoomId = m_nRoomID;

    m_client->SendData((char*)&rq, sizeof(rq));

    //暂停音频采集
    this->slot_closeAudio();

    //销毁声音播放
    for( auto ite = m_mapIDToAudioWrite.begin() ; ite != m_mapIDToAudioWrite.end();)
    {
        delete *ite ;
        //清空map
        ite = m_mapIDToAudioWrite.erase(ite);
    }

    //房间标志清空
    m_nRoomID = 0;
    //房间隐藏
    qDebug()<<"隐藏房间";
    m_gamesup->hide();
}


//关闭音频
void mygp::slot_closeAudio()
{
    if(m_pAudioRead)
    {
        m_pAudioRead->PauseAudio();
    }
}
void mygp::loadSqlAndSetMusicList() // 加载sql 并设置歌单 音量
{
    //首先要获取路径  设置sql
    QString DBDir = QDir::currentPath() + "/sql/";
    QString FileName = "music.db";
    QDir tempDir;
    tempDir.setPath( DBDir );
    //看路径是否存在 //路径是否存在 没有就创建
    if( !tempDir.exists( DBDir  ))
    {
        qDebug()<< "不存在该路径";
        tempDir.mkdir(DBDir );
    }

    QFile tempFile ;
    if( tempFile.exists( DBDir + FileName) )
    {//有数据库 加载
        qDebug()<< "有数据库";
        m_sql->ConnectSql( DBDir + FileName  ); //传入数据库绝对路径
        QStringList resList;
        QString sqlStr = "select musicName , musicPath from t_musicList;";
        bool res = m_sql->SelectSql( sqlStr , 2 , resList );

        if( !res )
        {
            return;
        }

    }
    else
    {
        //没有数据库 要创建
        qDebug()<< "没有数据库";
        tempFile.setFileName( DBDir + FileName );
        if( !tempFile.open(QIODevice::WriteOnly | QIODevice::Text )) //创建文件
        {
            qDebug()<< "数据库创建失败";
            QMessageBox::information(this , "提示","数据库创建失败,会导致无法写入歌曲");

        }else
        {
            qDebug()<< "数据库创建";
            tempFile.close();
            m_sql->ConnectSql( DBDir + FileName  ); //传入数据库绝对路径
            //创建表
            QString sqlStr = "create table t_game (gameName varchar(260) , gamePath varchar(260));";
            m_sql->UpdateSql( sqlStr );


        }
    }
}


//登陆槽函数
void mygp::slot_loginCommit(QString name,QString password)
{
    //发送给服务器
    m_UserName=name;
    STRU_LOGIN_RQ rq;
    std::string strTmp = name.toStdString();
    char* buf = (char*) strTmp.c_str();
    strcpy_s(  rq.m_szUser ,    MAX_SIZE , buf);

    //转存用户名
    strcpy_s(m_userName , rq.m_szUser);

    QByteArray ba = GetMD5(password);
    memcpy ( rq.m_szPassword , ba.data() , ba.length());

    m_client->SendData( (char*)&rq , sizeof(rq));
    qDebug()<<rq.m_szPassword;
    qDebug()<<rq.m_szUser;
}


//注册槽函数
void mygp::slot_registerCommit(QString name,QString password)
{
    //发送给服务器
    STRU_REGISTER_RQ rq;
    std::string strTmp = name.toStdString();
    char* buf = (char*) strTmp.c_str();
    strcpy_s(  rq.m_szUser ,    MAX_SIZE , buf);
    QByteArray ba = GetMD5(password);
    memcpy ( rq.m_szPassword , ba.data() , ba.length());

    m_client->SendData( (char*)&rq , sizeof(rq));
    qDebug()<<rq.m_szPassword;
    qDebug()<<rq.m_szUser;
}


//客户端接收服务器信息处理
void mygp::slot_clientDealData(char* buf,int len)
{
    int nType = *(int*) buf; //*(int*) 按四个字节取
    switch( nType )
    {
    case DEF_PACK_LOGIN_RS:
        dealLoginRs(buf,len);
        break;
    case DEF_PACK_REGISTER_RS:
        dealRegisterRs(buf,len);
        break;
    case DEF_PACK_GAMEUP_RS:
        dealGameup(buf,len);
        break;
    case DEF_PACK_GAMEUPUP_RS:
        dealgameupup(buf ,len);
        dealGameup(buf,len);
        break;
    case  DEF_PACK_GAMEDEL_RS:
        delgamerq(buf,len);
        break;
    case  DEF_PACK_DOWNLOAD_RS:
        downloadinfoRs(buf,len);
        break;
    case  DEF_PACK_GAMEDOWN_RS:
        downloadblock(buf,len);
        break;
    case  DEF_PACK_CREATEROOM_RS:
        CreateRoomRS(buf,len);
        break;
    case  DEF_PACK_GAMESELECT_RS:
        dealselectrs(buf,len);
        break;
    case  DEF_PACK_GAMEHOT_RS:
        dealgamehot(buf,len);
        break;
    case DEF_PACK_ADD_FRIEND_RQ:
        qDebug()<<  "DEF_PACK_ADD_FRIEND_RQ";
        slot_dealAddFriendRq(buf, len);
        break;
    case DEF_PACK_ADD_FRIEND_RS:
        qDebug()<<  "DEF_PACK_ADD_FRIEND_RS";
        slot_dealAddFriendRs(buf, len);
        break;
    case DEF_PACK_FRIEND_INFO:
        qDebug()<<  "DEF_PACK_FRIEND_INFO";
        slot_FriendInfo(buf, len);
        break;
    case DEF_PACK_DYNAMICALLY_PUBLISH_RS:
        qDebug()<<  "DEF_PACK_DYNAMICALLY_PUBLISH_RS";
        slot_publishrs(buf, len);
        break;
    case DEF_PACK_SERVER_DYNAMICALLY_RQ:
        qDebug()<<  "DEF_PACK_DYNAMICALLY_PUBLISH_RS";
        slot_getdynamically(buf, len);
        break;
    case DEF_PACK_JOINROOM_RS:
        dealJoinRoomRs(buf,len);
        break;
    case DEF_PACK_ROOM_MEMBER:
        dealMemberRq(buf,len);
        break;
    case DEF_PACK_LEAVEROOM_RS:
        dealLeaveRs(buf,len);
        break;
    case DEF_PACK_AUDIO_FRAME:
        dealAudioFrame(buf,len);
        break;

    }
    delete[] buf;
}


////登录请求结果
//#define userid_no_exist      0
//#define password_error       1
//#define login_sucess         2
//#define user_online          3


void mygp::dealGameup(char *buf, int len)
{

    STRU_GAMEUP_RS*rs=(STRU_GAMEUP_RS *)buf;
    if(rs->result==true)
    {
        m_anager->flag=true;
        QMessageBox::about( this->m_anager , "提示", "服务器中已存在上传完毕"  );//秒传

    }
    else
    {

        emit  managerDlg::  m_anager->SIG_UploadFile(m_anager->filePath );

        m_anager-> count=1;
    }
}

void mygp::dealgameupup(char *buf, int len)
{
    STRU_GAMEUPUP_RS*rs=(STRU_GAMEUPUP_RS*)buf;
    if(rs->result==true)
    {
        QMessageBox::about( this->m_anager , "提示", "上传完毕"  );
        m_anager->clear();
    }
    else
    {
        QMessageBox::about( this->m_anager , "提示", "上传失败"  );
    }
}

void mygp::delgamerq(char *buf, int len)
{
    STRU_GAMEDEL_RS*rs=(STRU_GAMEDEL_RS*)buf;
    if(rs->result==true)
    {
        QMessageBox::about( this->m_anager , "提示", "删除成功"  );
    }
    else{
        QMessageBox::about( this->m_anager , "提示", "文件不存在"  );
    }

}

//处理服务器登录回复
void mygp::dealLoginRs(char* buf,int len)
{
    STRU_LOGIN_RS * rs = (STRU_LOGIN_RS *)buf;
    switch( rs->m_lResult )
    {
    case userid_no_exist:
        QMessageBox::information( this->m_login , "提示", "用户不存在, 登录失败"  );
        break;
    case password_error:
        QMessageBox::information( this->m_login , "提示", "密码错误, 登录失败"  );
        break;
    case login_sucess:
        this->m_login->hide();
        this->show();
        //        this->ui->lb_name->setText( m_userName );
        m_userID = rs->m_UserID;
        STRU_GAMEHOT_RQ rq;
        m_client->SendData( (char*)&rq , sizeof(rq));

        break;
    }
}

////注册请求结果
//#define userid_is_exist      0
//#define register_sucess      1


//处理服务器注册回复
void mygp::dealRegisterRs(char* buf,int len)
{
    STRU_REGISTER_RS * rs = (STRU_REGISTER_RS *)buf;
    switch( rs->m_lResult )
    {
    case userid_is_exist:
        QMessageBox::information( this->m_login , "提示", "用户已存在, 注册失败"  );
        break;
    case register_sucess:
        QMessageBox::information( this->m_login , "提示", "注册成功"  );
        break;
    }
}



void mygp::on_toolButton_2_clicked()
{

}


//添加游戏
void mygp::on_pushButton_2_clicked()
{
    m_addgame->show();

    //    //弹窗 选择音乐文件 获取文件的绝对路径 存路径 需要字符串的数组
    //    QStringList path = QFileDialog::getOpenFileNames( this,"选择歌曲","./../music");
    //    //1.父类 2.标题 3.默认路径 4.文件过滤    //去重
    //    bool hasSame = false;
    //    for( int i = 0 ; i < path.count() ; ++i)
    //    {
    //        hasSame = false;
    //        for( int j = 0 ; j < m_gameCount ; ++j) //遍历歌单看有没有重复的
    //        {
    //            if( m_mNameToPostion.find(gname) = m_mNameToPostion.end())
    //            {

    //            }
    //            if( path[i] == m_musicList[j])
    //            {
    //                hasSame = true;
    //                break;
    //            }
    //        }
    //        if( !hasSame)
    //        {
    //            m_musicList[ m_musicCount++ ]  = path[i];
    //            //同时添加到控件  -- 添加歌曲名
    //            QFileInfo  info(path[i]);
    //            //info.baseName(); // 文件名   /music/稻香.mp3  -->baseName 是 稻香            ui->lw_musicList->addItem( info.baseName() );
    //                // 插入sql
    //            QString sqlStr =QString("insert into t_musicList (musicName , musicPath) values ('%1','%2')")
    //                    .arg(info.baseName()).arg(path[i]); //格式化字符串            m_sql->UpdateSql( sqlStr );        }    }    if( m_musicCount != 0 )    {        ui->lw_musicList->setCurrentRow(0);    }

    //        }
    //    }
}

void mygp::on_toolButton_3_clicked()
{

    this->hide();

}
//管理员
void mygp::on_pushButton_5_clicked()
{
    m_anager->show();
}

#include "gamesup.h"

void mygp::on_gamelist_doubleClicked(const QModelIndex &index)
{

    qDebug()<<resList2[ui->gamelist->currentIndex().row()];

    Process1 = new QProcess();
    Process1->start(resList2[ui->gamelist->currentIndex().row()]);

    qDebug()<< ui->gamelist->currentIndex().row();
    qDebug()<<resList2[ui->gamelist->currentIndex().row()];

    m_gamesup->move(1450,400);
    m_gamesup->show();
}

void mygp::slot_killProcess()
{
    qDebug()<<"kill 进程";
    if(myProcess)
    {
        myProcess->close();
        myProcess->kill();
    }
    if(Process1)
    {
        Process1->close();
        Process1->kill();
    }
    //m_gamesup->hide();
}


void mygp::on_pushButton_6_clicked()
{
    sqlStr =QString("delete from t_game where rowid = '%1'").arg(indexs)  ;

    res = m_sql->UpdateSql(sqlStr);
    if(res >0)
        slot_updatalist();
    else
        qDebug()<<"fail del ";
}


void mygp::on_gamelist_clicked(const QModelIndex &index)
{
    indexs= index.row();
    qDebug()<<index.row();

}

//在线搜索
void mygp::on_pushButton_3_clicked()
{
    QString str = ui->lineEdit_2->text();
    STRU_GAMESELECT_RQ rq;
    //赋值
    std::string strTmp = str.toStdString();
    char* buf = (char*) strTmp.c_str();
    strcpy_s( rq.m_name , MAX_SIZE , buf);

    //发送请求包
    m_client->SendData((char*)&rq , sizeof(rq));

    ui->lineEdit_2->setText("" );


}


//下载请求包
void mygp::on_pb_down_clicked()
{
    QString name = ui-> le_down->text();
    STRU_DOWNLOAD_RQ rq;
    std::string strTmp = name.toStdString();
    char* buf = (char*) strTmp.c_str();
    strcpy_s(  rq.m_name ,    MAX_SIZE , buf);
    m_client->SendData( (char*)&rq , sizeof(rq));


}

void mygp::downloadinfoRs(char *buf, int len)
{
    STRU_DOWNLOAD_RS * rs = (STRU_DOWNLOAD_RS *)buf;
    FileInfo * info = new FileInfo;
    // videoid 作为文件的标示 , fileid 用来区分不同控件

    info->pFile=nullptr;
    info->filePos=0;
    strcpy_s(info->fileName,MAX_SIZE,rs->m_name);
    info->fileSize=rs->m_nFileSize;
    sprintf(info->filePath ,"F:\\44444444444\\downexe\\%s",info->fileName);
    info->pFile =new QFile(info->filePath);


    if( info->pFile->open(QIODevice::WriteOnly))
    {
        m_mapfileTOFileInfo[info->fileName ] = info;
        qDebug()<<info->fileName;
    }else
    {
        delete info->pFile;
        delete info;
    }
    qDebug()<<info->fileName;




}
void mygp::downloadblock(char *buf, int len)
{
    STRU_GAMEDOWN_RS * rs = (STRU_GAMEDOWN_RS *)buf;
    auto ite = m_mapfileTOFileInfo.find( rs->m_filename );
    qDebug()<<rs->m_filename;
    if(  ite ==  m_mapfileTOFileInfo.end())  return;
    qDebug()<<rs->m_filename;
    FileInfo* info = m_mapfileTOFileInfo[ rs->m_filename ];

    int64_t res =  info->pFile->write( rs->m_file , rs->blocksize );
    info->filePos += res;
    qDebug()<<info->filePos;
    qDebug()<<info->fileSize;
    if( info->filePos >= info->fileSize )
    {
        //关闭文件
        info->pFile->close();
        //删除该节点
        m_mapfileTOFileInfo.erase( ite );
        //回收info
        delete  info->pFile;
        delete info;
        info = NULL;
        QMessageBox::about(this, "提示","下载完成");
    }

    ui->le_down->setText(" ");
}
//处理搜索回复
void mygp::dealselectrs(char *buf, int len)
{
    STRU_GAMESELECT_RS * rs = (STRU_GAMESELECT_RS *)buf;
    if(rs->result)
    {
        ui->le_down->setText( "" );
        ui->le_down->setText( rs->m_name );

    }
    else{
        ui->le_down->setText( "" );
        ui->le_down->setText( rs->m_name );
    }

}
//处理热度回复

void mygp::dealgamehot(char *buf, int len)
{
    STRU_GAMEHOT_RS*rs=(STRU_GAMEHOT_RS*)buf;

    ui->textBrowser->append( rs->m_name);
    if(rs->count==1)
    {

        ui->pushButton_4->setText(rs->m_name );
    }
    if(rs->count==2)
    {

        ui->pushButton_7->setText(rs->m_name );
    }

    if(rs->count==3)
    {

        ui->pushButton_8->setText(rs->m_name );
    }


}
//处理 发布回复
void mygp::slot_publishrs(char *buf, int len)
{
    STRU_DYNAMICALLY_PUBLISH_RS*rs=(STRU_DYNAMICALLY_PUBLISH_RS*)buf;
    //保存发布的动态编号
    int c_id=rs->c_id;
    if( rs->result==true)
    {
        QMessageBox::about(this,"提示","发布成功");
        ui->textEdit_2->setText("");
    }
    else
    {
        QMessageBox::about(this,"提示","发布失败");
    }

}
//获取好友动态
void mygp::slot_getdynamically(char *buf, int len)
{
    STRU_SERVER_DYNAMICALLY_RQ*rq=(STRU_SERVER_DYNAMICALLY_RQ*)buf;
    UserItem * item = new UserItem;
    qDebug()<<"qwertyui";
    char str[10]="0";
    itoa(rq->m_nUserId,str,10);
    item->ui->lb_name->setText(str);
    item->ui->lb_feeling->setText(rq->m_text);
    item->ui->lb_time->setText(rq->time);
    m_widgetList2->addItem(item);
    m_mapIDToUserItem2[  rq->m_nUserId ] = item;

    //mainlayout->insertWidget(0,item,0,Qt::AlignTop);
    //mainlayout->addStretch();

}
//菜单  添加好友
void mygp::on_pushButton_16_clicked()
{
    if( m_mainMenu )
    {
        QPoint p = QCursor::pos() ;
        QSize size = m_mainMenu->sizeHint();  //最终的大小 prefered size
        int  y = p.y () - size.height();
        m_mainMenu->exec( QPoint( p.x() , y ) );
    }

}
// 发布动态 请求
void mygp::on_pushButton_17_clicked()
{
    STRU_DYNAMICALLY_PUBLISH_RQ rq;
    rq.m_nUserId=m_userID;
    QString name = ui->textEdit_2->toPlainText();
    std::string strTmp = name.toStdString();
    char* buf = (char*) strTmp.c_str();
    strcpy_s(  rq.m_text,    MAX_SIZE , buf);
    m_client->SendData( (char*)&rq , sizeof(rq));
}
//加入房间
void mygp::on_pushButton_15_clicked()
{
    QString roomNum = QInputDialog::getText(this,"加入房间","输入房间号");
    QRegExp reg("[0-9]{1,10}");
    if(reg.exactMatch(roomNum) )
    {

        STRU_JOINROOM_RQ rq;
        m_nRoomID = roomNum.toInt();
        rq.m_RoomID = m_nRoomID;
        qDebug()<<"加入房间号";
        qDebug()<<m_nRoomID;
        rq.m_UserID = m_userID;
        m_client->SendData((char*)&rq , sizeof(rq));

    }
    else
        QMessageBox::about(this, "提示","必须是纯数字");
}
