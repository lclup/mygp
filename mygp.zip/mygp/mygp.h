#ifndef MYGP_H
#define MYGP_H

#include <QWidget>
#include"Packdef.h"
#include"logindialog.h"
#include"qmytcpclient.h"
#include <QList>
#include <QMap>
#include <QMessageBox>
#include <QFileDialog>
#include<QProcess>
#include "addgame.h"
#include"managerdlg.h"
#include"csqlite.h"
#include"gamesup.h"
#include <QInputDialog>
#include<QMenu>
#include"useritem.h"
#include"IMToolBox.h"
#include"notify.h"

QT_BEGIN_NAMESPACE
namespace Ui { class mygp; }
QT_END_NAMESPACE

class mygp : public QWidget
{
    Q_OBJECT

public:
    mygp(QWidget *parent = nullptr);
    ~mygp();


public slots:
    void slot_loginCommit(QString name, QString password);
    void slot_registerCommit(QString name, QString password);
    void slot_clientDealData(char *buf, int len);
    void slot_updatalist();
    void slot_dealMenu(QAction* action);
    void slot_addFriendRq(QString name);
    void slot_FriendInfo(char *buf, int nlen);
    void slot_dealAddFriendRq(char * buf,int nlen);
    void slot_dealAddFriendRs(char *buf, int nlen);
    void CreateRoomRS(char *buf, int len);
    void dealJoinRoomRs(char *buf, int nlen);
    void dealMemberRq(char *buf, int nlen);
    void dealLeaveRs(char *buf, int nlen);
    void dealAudioFrame(char *buf, int nlen);
    void slot_quitRoom(int id);
    void  slot_killProcess();
    void slot_closeAudio();

public:
    void dealLoginRs(char *buf, int len);
    void dealRegisterRs(char *buf, int len);
    void dealGameup(char *buf, int len);
    void dealgameupup(char *buf, int len);
    void  delgamerq(char *buf, int len);
    void downloadinfoRs(char *buf, int len);
    void downloadblock(char *buf, int len);
    void dealselectrs(char *buf, int len);
    void dealgamehot(char *buf, int len);
    void slot_publishrs(char *buf, int len);
    void slot_getdynamically(char *buf, int len);

private slots:
    void on_toolButton_2_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_toolButton_3_clicked();

    void on_pushButton_5_clicked();

    void on_gamelist_doubleClicked(const QModelIndex &index);

    void on_pushButton_6_clicked();

    void on_gamelist_clicked(const QModelIndex &index);

    void on_pushButton_3_clicked();

    void on_pushButton_14_clicked();
    void slot_openAudio(QByteArray ba) ;

    void on_pb_down_clicked();

    void on_pushButton_16_clicked();

    void on_pushButton_17_clicked();

    void on_pushButton_15_clicked();

signals:

    void SIG_updatalist();
    void SIG_RoomNum(int );
    void SIG_addFriend(QString name);

public:
    Ui::mygp *ui;
    QMap<QString , FileInfo*> m_mapfileTOFileInfo;
    LoginDialog * m_login;
    QMyTcpClient * m_client;
    addgame *m_addgame;
    managerDlg*m_anager;
    int m_userID;
    QString m_UserName;
    QMap<int , UserItem* > m_mapIDToUserItem;
    QMap<int , UserItem* > m_mapIDToUserItem2;
    IMToolList * m_widgetList;
    IMToolList * m_widgetList2;
    QVBoxLayout *mainlayout;
    char m_userName[MAX_SIZE];
    int m_gameCount;
    QProcess *myProcess;
    QProcess *Process1;
    void loadSqlAndSetMusicList(); // 加载sqlite
    CSqlite *m_sql;
    bool res ;
    QString sqlStr ;
    QStringList resList;
    QStringList resList2;
    int indexs;
    quint32 m_nRoomID;
    QMenu * m_mainMenu;
    gamesup *m_gamesup;
    int m_RoomID;
    Audio_Read *m_pAudioRead;
    QMap<int , Audio_Write*> m_mapIDToAudioWrite;

};

#endif // MYGP_H
